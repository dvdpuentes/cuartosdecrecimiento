package com.example.arduinoconnector;

import android.app.admin.DeviceAdminReceiver;

public class DeviceAdminReceiverSample extends DeviceAdminReceiver {
}
